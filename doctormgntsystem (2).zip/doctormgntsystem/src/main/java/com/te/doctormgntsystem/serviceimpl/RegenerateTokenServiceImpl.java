package com.te.doctormgntsystem.serviceimpl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.hibernate.validator.internal.util.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.te.doctormgntsystem.dto.RefreshTokenDto;
import com.te.doctormgntsystem.entity.AppUser;
import com.te.doctormgntsystem.exception.DataNotFoundException;
import com.te.doctormgntsystem.jwtfilter.JwtTokenGeneration;
import com.te.doctormgntsystem.repository.AppUserRepository;
import com.te.doctormgntsystem.service.RegenerateTokenService;

import io.jsonwebtoken.Claims;

@Service
public class RegenerateTokenServiceImpl implements RegenerateTokenService {

	@Autowired
	private JwtTokenGeneration jwtTokenGeneration;
	@Autowired
	private AppUserRepository appUserRepository;

	@Override
	public String generateNewAccessToken(RefreshTokenDto refreshTokenDto) {

		String refreshToken = refreshTokenDto.getRefreshToken();

		String userEmail = jwtTokenGeneration.extractUsername(refreshToken);
		AppUser userDetails = appUserRepository.findByEmail(userEmail).get();

		if (jwtTokenGeneration.isTokenValid(refreshToken, userDetails)) {
			String regeneratedAccessToken = jwtTokenGeneration.regenerateAccessToken(userDetails);
			return regeneratedAccessToken;

		}
		throw new DataNotFoundException("Data Not Found");

	}

}
