package com.te.doctormgntsystem.dto;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Lob;
import javax.persistence.Transient;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import org.springframework.web.multipart.MultipartFile;

import com.te.doctormgntsystem.entity.DoctorSpecialization;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class DoctorDto {
    
	@NotBlank(message = "Doctor name may not be blank")
    private String doctorName;
	
	@NotBlank(message = "DoctorEmail may not be blank")
	@Email     //it will check the format,domain,and syntax validation it should be in example@gmail.com
    private String doctorEmail;
	
	@NotBlank(message = "DoctorSpecialization may not be blank")
	@Enumerated(EnumType.STRING)
	private DoctorSpecialization doctorSpecialization;
	
	@NotBlank(message = "Doctor phone number not be blank")
	@Digits(integer = 0-9, fraction = 0)
	private String doctorPhoneNumber;
	
	@NotBlank(message = "password not to be blank")
	private String password;
	
	private String name;
	private String type;
	
	private String imageUrl;
//	@Lob
//	private byte[] imageData;
	@Transient
	private MultipartFile file;

}
