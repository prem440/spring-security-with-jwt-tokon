package com.te.doctormgntsystem.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.te.doctormgntsystem.dto.BookingAppointmentDto;

public interface DoctorService {


	List<BookingAppointmentDto> allAppointments(Integer doctorId);

	

}
