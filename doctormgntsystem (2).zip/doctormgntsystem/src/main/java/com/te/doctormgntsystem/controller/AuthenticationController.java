package com.te.doctormgntsystem.controller;

import java.io.IOException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.te.doctormgntsystem.dto.DoctorDto;
import com.te.doctormgntsystem.dto.LoginDto;
import com.te.doctormgntsystem.dto.UserDto;
import com.te.doctormgntsystem.response.AppResponse;
import com.te.doctormgntsystem.response.Response;
import com.te.doctormgntsystem.service.AuthenticateService;

@RestController
@RequestMapping("/authcontrol")
public class AuthenticationController {

	@Autowired
	private AuthenticateService authenicateService;

	@Autowired
	private Response response;

	@Autowired
	private AppResponse appResponse;
	

	@PostMapping("/register")
	public ResponseEntity<Response> register(@RequestBody UserDto userDto) {
		return ResponseEntity.status(HttpStatus.CREATED).body(new Response(false, "registered Successfully",
				HttpStatus.CREATED, authenicateService.registerUser(userDto)));
	}

	@PostMapping("/authenticate/login")
	public ResponseEntity<AppResponse> loginModule(@RequestBody LoginDto loginDto) {
		Map<String, String> authenticateLogin = authenicateService.authenticateLogin(loginDto);
		return ResponseEntity.status(HttpStatus.OK).body(new AppResponse(false, "Login Successfully", HttpStatus.OK, authenticateLogin));
				}

	@PostMapping("/register/image/upload")
	public ResponseEntity<Response> registerDoctorModule(@ModelAttribute DoctorDto doctorDto) throws IOException {
		return ResponseEntity.status(HttpStatus.CREATED).body(new Response(false, "Registration Successfull",
				HttpStatus.CREATED, authenicateService.registerDoctorModule(doctorDto)));
	}

}
