package com.te.doctormgntsystem.exceptionHandler;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MethodAuthorizationEntryPoint extends AccessDeniedHandlerImpl{
	
	

	    @Override
	    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
	        // Check if the user is already authenticated
	        if (request.getUserPrincipal() != null && request.getUserPrincipal().getName() != null) {
	            // User is authenticated, but access is denied
	            // Handle the access denied case as needed
	            // You can send a custom response or redirect the user to an error page
	        	try {
	        		
	            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Access Denied");
	            response.setHeader("error", accessDeniedException.getMessage());
	            response.setStatus(HttpStatus.FORBIDDEN.value());
	            HashMap<String, String> error = new HashMap<>();
	            error.put("Status", HttpStatus.FORBIDDEN.toString());
	            error.put("error", "Server Denies to Access to the requested code");
				error.put("message", "Access Denied");
				log.error(accessDeniedException.getMessage());
				response.setContentType(MediaType.APPLICATION_JSON_VALUE);
				// indicating that the response body will be in JSON format.
				new ObjectMapper().writeValue(response.getOutputStream(), error);
				// The ObjectMapper is used to convert the error map into a JSON string and
				// write it to the response output stream.
	        }catch(Exception e){
	        	e.getStackTrace();
	        	
	        }
	    }
	}

	
	

//	@Override
//	public void handle(HttpServletRequest request, HttpServletResponse response,
//			AccessDeniedException exception) throws IOException, ServletException {
//		try {
//		 response.sendError(HttpServletResponse.SC_FORBIDDEN, "Access denied");
//		 response.setHeader("error", exception.getMessage());
//		 response.setStatus(HttpStatus.FORBIDDEN.value());
//			HashMap<String, String> error = new HashMap<>();
//			error.put("statusCode", HttpStatus.FORBIDDEN.toString());
//			error.put("error", "Server Denies to Access to the requested code");
//			error.put("message", "Access Denied");
//			error.put("isExpired", "" + true);
//			log.error(exception.getMessage());
//			response.setContentType(MediaType.APPLICATION_JSON_VALUE);
//			// indicating that the response body will be in JSON format.
//			new ObjectMapper().writeValue(response.getOutputStream(), error);
//			// The ObjectMapper is used to convert the error map into a JSON string and
//			// write it to the response output stream.
//
//		}catch (Exception e) {
//			e.getStackTrace();
//		}
//    }
//	
}
