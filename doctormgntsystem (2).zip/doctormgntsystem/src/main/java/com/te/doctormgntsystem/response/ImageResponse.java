package com.te.doctormgntsystem.response;

import java.util.List;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ImageResponse {

	private boolean error;
	private String message;
	private HttpStatus status;
	private Object data;
	
	private List<byte[]> imageBytes;
}
