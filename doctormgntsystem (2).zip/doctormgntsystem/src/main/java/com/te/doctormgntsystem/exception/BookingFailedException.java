package com.te.doctormgntsystem.exception;

public class BookingFailedException extends RuntimeException {

	public BookingFailedException(String message) {
		super(message);
	}
}
