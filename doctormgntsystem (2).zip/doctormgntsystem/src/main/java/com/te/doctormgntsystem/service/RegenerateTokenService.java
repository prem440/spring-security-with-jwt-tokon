package com.te.doctormgntsystem.service;

import com.te.doctormgntsystem.dto.RefreshTokenDto;

public interface RegenerateTokenService {

	public String generateNewAccessToken(RefreshTokenDto refreshTokenDto);
}
