package com.te.doctormgntsystem.service;

import java.io.IOException;
import java.util.Map;

import com.te.doctormgntsystem.dto.DoctorDto;
import com.te.doctormgntsystem.dto.LoginDto;
import com.te.doctormgntsystem.dto.UserDto;
import com.te.doctormgntsystem.response.AuthResponse;

public interface AuthenticateService {
	
	UserDto registerUser(UserDto userDto);
	
//	DoctorDto registerDoctor(DoctorDto doctorDto);
	Map<String, String> authenticateLogin(LoginDto loginDto);
	
	String registerDoctorModule(DoctorDto doctorDto) throws IOException;
	
//	DoctorDto registerDoctorImage(DoctorDto doctorDto) throws IOException;
	

}
