package com.te.doctormgntsystem.jwtfilter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.te.doctormgntsystem.exceptionHandler.CustomAuthenticationEntryPoint;
import com.te.doctormgntsystem.exceptionHandler.MethodAuthorizationEntryPoint;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfiguration {

	private final JwtAuthenticationFilter jwtAuthenticationFilter;// (C)

	private final AuthenticationProvider authenticationProvider; // (I)

	@Autowired
	private CustomAuthenticationEntryPoint customAuthenticationEntryPoint;
	
	@Autowired
	private MethodAuthorizationEntryPoint methodAuthorizationEntryPoint;

	// This filter chain is responsible for processing the request through a series
	// of filters to enforce security policies
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

		System.err.println("Security Congig");

		http

				.csrf().disable() // cross-site request forgery
				.authorizeRequests()

				.antMatchers("/authcontrol/**").permitAll()
				.antMatchers("/user/**").hasRole("USER")

				.antMatchers("v2/doctor/**").hasRole("DOCTOR")
				.anyRequest() // All other requests are permitted to all
																			// users.
				.authenticated().and()
				.exceptionHandling()
				.accessDeniedHandler(methodAuthorizationEntryPoint)
				.authenticationEntryPoint(this.customAuthenticationEntryPoint)

				/*
				 * This line states that any other request that doesn't match the previous
				 * patterns should be authenticated, meaning it requires the user to be logged
				 * in.
				 */
//		.permitAll() --if we give this it is give permisssion to all urls which extends with the 
				.and().sessionManagement()
				/*
				 * the session management policy is set to stateless, which means that no
				 * session will be created or used to store user information.
				 * 
				 */
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()

				.authenticationProvider(authenticationProvider)
				// This provider is responsible for authenticating users based on the
				// authentication mechanism configured for the application.

				.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
		/*
		 * The jwtAuthenticationFilter is a custom filter that extracts the JSON Web
		 * Token (JWT) from the request's header and validates it. If the token is
		 * valid, the filter sets the user's authentication details, allowing the user
		 * to access the requested resource.
		 */

		return http.build();
	}
}
