package com.te.doctormgntsystem.jwtfilter;

import java.security.Key;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.tomcat.jni.Time;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.te.doctormgntsystem.exception.InvalidTokenException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Component
@Data
public class JwtTokenGeneration {

	private static final String SECRETKEY = "4D635166546A576D5A7134743777217A25432A462D4A614E645267556B587032";

	private Map<String, String> accessTokenMap = new HashMap<>(); // Store access tokens
    private Map<String, String> refreshTokenMap = new HashMap<>(); // Store refresh tokens
    private Set<String> tokenBlacklist = new HashSet<>(); // Store revoked tokens



    public Map<String, String> generateNewToken(UserDetails userDetails) {
    	
    	Map<String, Object> claims = new HashMap<>();
    	claims.put("roles", userDetails.getAuthorities());
        // Generate a new access token
        String newAccessToken = Jwts.builder()
                .setClaims(claims)
                .setSubject(userDetails.getUsername())
                .setIssuer("Brunda V")
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setId(UUID.randomUUID().toString())
                .setExpiration(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(1)))
                .signWith(getSignKey(), SignatureAlgorithm.HS256)
                .compact();

        Map<String, Object> claimsRefresh = new HashMap<>();
        // Generate a new refresh token
        String newRefreshToken = Jwts.builder()
                .setClaims(claimsRefresh)
                .setSubject(userDetails.getUsername())
                .setIssuer("Brunda V")
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setId(UUID.randomUUID().toString())
                .setExpiration(new Date(System.currentTimeMillis() + TimeUnit.DAYS.toMillis(30)))
                .signWith(getSignKey(), SignatureAlgorithm.HS256)
                .compact();

        // Revoke the previous access token, if any
        String previousAccessToken = accessTokenMap.get(userDetails.getUsername());
        if (previousAccessToken != null) {
            addToBlacklist(previousAccessToken);
        }

        // Revoke the previous refresh token, if any
        String previousRefreshToken = refreshTokenMap.get(userDetails.getUsername());
        if (previousRefreshToken != null) {
            addToBlacklist(previousRefreshToken);
        }

        // Store the new access token and refresh token
        accessTokenMap.put(userDetails.getUsername(), newAccessToken);
        refreshTokenMap.put(userDetails.getUsername(), newRefreshToken);

        // Return the new tokens
        Map<String, String> tokens = new HashMap<>();
        tokens.put("accessToken", newAccessToken);
        tokens.put("refreshToken", newRefreshToken);
        return tokens;
    }
    
    public String regenerateAccessToken(UserDetails userDetails) {
    	
    	Map<String, Object> claims = new HashMap<>();
    	claims.put("role", userDetails.getAuthorities());
    	
    	String regeneratedAccessToken = Jwts.builder()
    	.setClaims(claims)
    	.setSubject(userDetails.getUsername())
    	.setIssuer("Brunda V")
    	.setIssuedAt(new Date(System.currentTimeMillis()))
    	.setId(UUID.randomUUID().toString())
    	.setExpiration(new Date(System.currentTimeMillis()+ TimeUnit.DAYS.toMillis(30)))
    	.signWith(getSignKey(), SignatureAlgorithm.HS256)
    	.compact();
    	
    	 // Revoke the previous access token, if any
        String previousAccessToken = accessTokenMap.get(userDetails.getUsername());
        if (previousAccessToken != null) {
            addToBlacklist(previousAccessToken);
        }
        
        // Store the new access token and refresh token
        accessTokenMap.put(userDetails.getUsername(), regeneratedAccessToken);
        // Return the new tokens
        Map<String, String> tokens = new HashMap<>();
        tokens.put("accessToken", regeneratedAccessToken);
    	
		return regeneratedAccessToken;
		
    	
    }

    public void addToBlacklist(String token) {
        String jti = extractClaim(token, Claims::getId);
        if (jti != null) {
            tokenBlacklist.add(jti);
        }
    }

    public boolean isTokenBlacklisted(String token) {
        String jti = extractClaim(token, Claims::getId);
        return jti != null && tokenBlacklist.contains(jti);
    }

    public boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername())) && !isTokenExpired(token) && !isTokenBlacklisted(token);
    }

	public String extractUsername(String token) {
		return extractClaim(token, Claims::getSubject);
	}
	public String extractJti(String token) {
		return extractClaim(token, Claims::getId);
	}

	/*
	 * Claims are used to convey information about the user, such as the user's
	 * name, email address, or role, which can be used by the server to make
	 * authorization decisions. When a client sends a JWT token to the server, the
	 * server can decode the token and read the claims to extract the relevant
	 * information about the user.
	 */
	public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = extractAllClaims(token);
		return claimsResolver.apply(claims);
	}

	private Claims extractAllClaims(String token) {
		return Jwts.parserBuilder().setSigningKey(getSignKey()).build().parseClaimsJws(token).getBody();
	}

	private Key getSignKey() {
		byte[] keyBytes = Decoders.BASE64.decode(SECRETKEY);
		return Keys.hmacShaKeyFor(keyBytes);
	}

//	public boolean isTokenvalidate(String token, UserDetails userDetails) {
//		final String userName = extractUsername(token);
//		return (userName.equals(userDetails.getUsername())) && !isTokenExpired(token);
//	}


	public boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}

	public Date extractExpiration(String token) {
		return extractClaim(token, Claims::getExpiration);
	}

}















//public Map<String, String> generateTokens(UserDetails userDetails) {
//revokePreviousToken(userDetails.getUsername()); // Revoke previous tokens
//String accessToken = generateNewToken(userDetails);
//String refreshToken = generateRefreshToken(userDetails);
//tokenMap.put(userDetails.getUsername(), accessToken); // Store access token
//tokenMap.put(userDetails.getUsername() + "-refresh", refreshToken); // Store refresh token
//Map<String, String> tokens = new HashMap<>();
//tokens.put("accessToken", accessToken);
//tokens.put("refreshToken", refreshToken);
//return tokens;
//}


//public void validateToken(String token, UserDetails userDetails) {
//if (!isTokenvalidate(token, userDetails)) {
//	throw new InvalidTokenException("Invalid token");
//}
//}

