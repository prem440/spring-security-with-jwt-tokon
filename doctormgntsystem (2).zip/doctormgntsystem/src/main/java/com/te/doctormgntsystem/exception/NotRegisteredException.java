package com.te.doctormgntsystem.exception;

public class NotRegisteredException extends RuntimeException {

	public NotRegisteredException(String message) {
		super(message);
	}
}
