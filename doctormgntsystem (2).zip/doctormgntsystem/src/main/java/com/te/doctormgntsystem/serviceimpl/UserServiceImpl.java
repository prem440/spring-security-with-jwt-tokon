package com.te.doctormgntsystem.serviceimpl;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.zip.DataFormatException;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.te.doctormgntsystem.ImageCD;
import com.te.doctormgntsystem.dto.BookingAppointmentDto;
import com.te.doctormgntsystem.dto.DoctorDto;
import com.te.doctormgntsystem.dto.DoctorOneDto;
import com.te.doctormgntsystem.dto.DoctorRatingDto;
import com.te.doctormgntsystem.dto.UserOneDto;
import com.te.doctormgntsystem.entity.Appointment;
import com.te.doctormgntsystem.entity.Doctor;
import com.te.doctormgntsystem.entity.DoctorRating;
import com.te.doctormgntsystem.entity.User;
import com.te.doctormgntsystem.exception.DataNotFoundException;
import com.te.doctormgntsystem.exception.DoctorNotFoundException;
import com.te.doctormgntsystem.exception.TimeSlotAvailabilityException;
import com.te.doctormgntsystem.repository.AppointmentRepository;
import com.te.doctormgntsystem.repository.DoctorRatingRepository;
import com.te.doctormgntsystem.repository.DoctorRepository;
import com.te.doctormgntsystem.repository.UserRepository;
import com.te.doctormgntsystem.service.UserService;

import net.bytebuddy.asm.Advice.Local;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private DoctorRepository doctorRepository;

	@Autowired
	private AppointmentRepository appointmentRepository;
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private DoctorRatingRepository doctorRatingRepository;

	@Override
	public List<DoctorOneDto> getDoctor(String doctorPhoneNumber) {

		List<Doctor> findByDoctorPhoneNumber = doctorRepository.findByDoctorPhoneNumberContaining(doctorPhoneNumber);
		// The method findByDoctorPhoneNumberContaining is used to search for doctors
		// whose phone numbers contain the specified string "123456789".

		if (findByDoctorPhoneNumber == null) {
			throw new DoctorNotFoundException("Doctor Not Found");
		} else {
			List<DoctorOneDto> list = new ArrayList<>();

			for (Doctor doctor : findByDoctorPhoneNumber) {
				doctor.setAppointments(null);
				DoctorOneDto doctorOneDto = new DoctorOneDto();
				doctorOneDto.setImageUrl(doctor.getImageUrl());
				BeanUtils.copyProperties(doctor, doctorOneDto);

				list.add(doctorOneDto);

			}

			return list;

		}

	}

	@Override
	public List<DoctorOneDto> getAllDoctorList() {
		List<Doctor> findAll = doctorRepository.findAll();
		if(findAll == null ) {
			throw new DataNotFoundException("Doctor Data Not Found,Please Check the Database");
		}
		List<DoctorOneDto> list = new ArrayList<>();
		findAll.stream().forEach(i -> {
			DoctorOneDto doctorOneDto = new DoctorOneDto();
			BeanUtils.copyProperties(i, doctorOneDto);
			list.add(doctorOneDto);
		});
		return list;

	}

	@Override
	public String bookingAppointment(BookingAppointmentDto bookingAppointmentDto) {

		User user = userRepository.findById(bookingAppointmentDto.getId())
				.orElseThrow(()-> new UsernameNotFoundException("User Data Not Found"));
		Doctor doctor = doctorRepository.findById(bookingAppointmentDto.getDoctorId())
				.orElseThrow(()-> new DoctorNotFoundException("Doctor Data Not Found"));
		Appointment appointment = new Appointment();
		LocalDateTime localDateTime2 = bookingAppointmentDto.getLocalDateTime();
		List<Appointment> appointments = doctor.getAppointments();
		appointments.stream().forEach(i -> {
			LocalDateTime localDateTime = i.getLocalDateTime();
			long between = Duration.between(localDateTime, localDateTime2).toMinutes();
			if (between == 0.0) {
				throw new TimeSlotAvailabilityException("This Slot is already Booked");
			}

		});

		appointment.setLocalDateTime(localDateTime2);
		appointment.setUser(user);
		appointment.setDoctor(doctor);

		appointmentRepository.save(appointment);

		return "Booking Successfull";

	}

//	@PostAuthorize("hasRole('ROLE_USER')")
	@Override
	public String updateRatings(DoctorRatingDto doctorRatingDto) {

		Doctor doctor = doctorRepository.findById(doctorRatingDto.getDoctorId())
				.orElseThrow(()-> new DoctorNotFoundException("Doctor Not Found"));
		User user = userRepository.findById(doctorRatingDto.getId())
				.orElseThrow(()-> new DataNotFoundException("User Not Found"));
		DoctorRating doctorRating = new DoctorRating();
		doctorRating.setDoctorRating(doctorRatingDto.getDoctorRating());
		doctorRating.setDoctor(doctor);
		doctorRating.setUser(user);
		doctorRatingRepository.save(doctorRating);
		Double collect = doctor.getDoctorRating().stream()
				.collect(Collectors.averagingDouble(DoctorRating::getDoctorRating));
		System.err.println(collect);
		doctor.setAvgRating(collect);
		doctorRepository.save(doctor);

		return "Rating Added Successfully";

	}

}

